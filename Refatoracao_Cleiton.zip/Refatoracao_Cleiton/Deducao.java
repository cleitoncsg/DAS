package Refatoracao_Cleiton;

public class Deducao {
	private String descricao; 
	private float valor;
	
	public Deducao(String descricao, float valorDeducao) {
		this.descricao = descricao; 
		this.valor = valorDeducao;
	}

	
	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public float getValor() {
		return valor;
	}

	public void setValor(float valor) {
		this.valor = valor;
	}
	
	
}
