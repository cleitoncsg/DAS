package Refatoracao_Cleiton;

public class Rendimento {
	
	private String descricao; 
	private float valor; 
	private boolean tributavel;
	
	public Rendimento(String descricao, float valor, boolean tributavel) {
		this.descricao = descricao; 
		this.valor = valor; 
		this.tributavel = tributavel;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public float getValor() {
		return valor;
	}

	public void setValor(float valor) {
		this.valor = valor;
	}

	public boolean isTributavel() {
		return tributavel;
	}

	public void setTributavel(boolean tributavel) {
		this.tributavel = tributavel;
	}
}
