package Refatoracao_Cleiton;

public class CPF {

	final int[] cpf;
	
	public CPF(int[] cpf) {
		this.cpf = cpf;
	}
	
	public int[] getCPF() {
		return cpf;
	}
	
}
